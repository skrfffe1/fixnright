
<?php
  session_start();
  if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: ../../login/login.php');
  }
  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: ../../login/login.php");
  }
?>

<?php
include_once('../../include/config.php');
  include_once('../../include/config2.php');
  include '../../include/client/sidebar.php';
   $temp = $_REQUEST['editId'];
  $sql2 = " SELECT  * FROM   users  JOIN cardata ON users.id = cardata.plateid 
      
      WHERE   users.id = '$temp'";
  if(isset($_REQUEST['submit']) and $_REQUEST['submit']!=""){

  extract($_REQUEST);

  if($carbrand==""){

    header('location:'.$_SERVER['PHP_SELF'].'?msg=un');

    exit;

  

  }else{

    

    $userCount  = $db->getQueryCount('cardata','id');

    if($userCount[0]['total']<100){

      $data = array(
              'userphone'=>$userphone,
              'plateid'=>$plateid,
              'carbrand'=>$carbrand,
              'carmodel'=>$carmodel,
              'carmanufacturer'=>$carmanufacturer,
              'cartype'=>$cartype,
              'carserialnumber'=>$carserialnumber,
             
              
              
              );

      $insert = $db->insert('cardata',$data);

    

    }else{

    
      exit;

    }

  }

}
?>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/jquery.caret/0.1/jquery.caret.js"></script>
  <script src="https://www.solodev.com/_/assets/phone/jquery.mobilePhoneNumber.js"></script>



<!doctype html>

<html lang="en-US">

<head>

  <meta charset="UTF-8">

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <meta name="description" content="PHP CRUD with search and pagination in bootstrap 4">
  <meta name="keywords" content="PHP CRUD, CRUD with search and pagination, bootstrap 4, PHP">
  <meta name="robots" content="index,follow">



    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">



</head>



<body>

       <div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Add Car</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">
          <form role="form" method="post">    
             <div class="form-group">

                <input type="hidden" class="form-control" placeholder="plateid" name="plateid" id="plateid" value="<?php echo $temp?>"required>
              </div>      
             
                <div class="form-group">

                <input class="form-control" placeholder="Plate Number" name="userphone" id="userphone "required>
              </div>      
             
              <div class="form-group">
                <input class="form-control" placeholder="Brand" name="carbrand" id="carbrand" required>
              </div>

               <div class="form-group">
                <input class="form-control" placeholder="Model" name="carmodel" id="carmodel" required>
              </div>
              <div class="form-group">
                <input class="form-control" placeholder="Serial Number" name="carserialnumber" id="carserialnumber" required>
              </div>
                <div class="form-group">
                <input class="form-control" placeholder="Type" name="cartype" id="cartype" required>
              </div>
              <div class="form-group">
                <input class="form-control" placeholder="Car Manufacturer" name="carmanufacturer" id="carmanufacturer" required>
              </div>
            
             
           
         
              
              <hr>
            <button type="submit" name="submit" value="submit" id="submit" class="btn btn-success"><i class="fa fa-check fa-fw"></i>Save</button>
            <button type="reset" class="btn btn-danger"><i class="fa fa-times fa-fw"></i>Reset</button>
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>      
          </form>  
        </div>
      </div>
    </div>
</div>
            <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h4 class="m-2 font-weight-bold text-primary">Car Tables&nbsp;<a  href="employee_register.php" data-toggle="modal" data-target="#myModal" type="button" class="btn btn-primary bg-gradient-primary" style="border-radius: 0px;"><i class="fas fa-fw fa-plus"></i></a></h4>
            </div>
            
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0"> 
                  <thead>
                        <tr class="bg-primary text-white">
                          <th>Plate</th>
                          <th>Brand</th>
                          <th>Model</th>
                          <th>Make</th>
                          <th>Action</th>
                        </tr>
                     </thead>
                    <tbody>
                <?php                  
                        
                        $result = mysqli_query($con, $sql2) or die (mysqli_error($db));
                        while ($row = mysqli_fetch_assoc($result)) {
                        echo '<tr>';
                        echo '<td>'. $row['userphone'].'</td>';
                        echo '<td>'. $row['carbrand'].'</td>';
                        echo '<td>'. $row['carmodel'].'</td>';
                        echo '<td>'. $row['carbrand'].'</td>';


                      echo '<td align="right"> <div class="btn-group">
                      
                              <a type="button" class="btn btn-primary bg-gradient-primary" href="customer_car_details.php?action=edit & id='.$row['id'] . '"><i class="fas fa-fw fa-list-alt"></i> Details</a>
                            <div class="btn-group">
                              <a type="button" class="btn btn-primary bg-gradient-primary dropdown no-arrow" data-toggle="dropdown" style="color:white;">
                              ... <span class="caret"></span></a>
                            <ul class="dropdown-menu text-center" role="menu">
                                <li>
                                 </a>
                                  
                                  <a type="button" class="btn btn-warning bg-gradient-warning btn-block" style="border-radius: 0px;" href="employee_edit.php?action=edit & id='.$row['id']. '">
                                    <i class="fas fa-fw fa-edit"></i> Edit
                                  </a>
                                   <a type="button" class="btn btn-danger bg-gradient-btn-danger btn-block" style="border-radius: 0px;" href="../user-delete/customer_car_delete.php?delId='.$row['id']. '">
                                    <i class="fas fa-fw fa-trash"></i> Delete
                                  </a>

                                </li>
                            </ul>
                            </div>
                          </div> </td>';
                        echo '</tr> ';
                        }
                    ?> 
                    
                                    
                    </tbody>
                </table>
              </div>
            </div>
          </div>
       

              


        
              


         

  


</body>

<script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="../js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="jquery.dataTables.min.js"></script>
  <script src="dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="datatables-demo.js"></script>
  <script src="city.js"></script> 
  
</html>